package sample;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

//import java.awt.event.MouseEvent;
import javafx.scene.input.MouseEvent;

import java.io.*;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.logging.Level;

public class Main   {
    private static ArrayList<Player> players= new ArrayList<Player>();
    static HashMap<String, Image> images = new HashMap<String, Image>();


    public static void addPlayer(Player p){
        try {

            players=deserialize();
            System.out.println(players.size());
            players.add(p);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }

    public static void serialize() throws IOException {
        System.out.println("llallalalalallaaa");
        ObjectOutputStream out = null;
        try {
            out = new ObjectOutputStream (
                    new FileOutputStream("result.txt"));
            for (int i=0;i<players.size();i++)
                out.writeObject(players.get(i));
        }
        finally {
            out.close();
        }
    }

    public static ArrayList<Player> deserialize() throws IOException, ClassNotFoundException {
        ObjectInputStream in = null;
        ArrayList<Player> p = new ArrayList<Player>();
        try {
            in = new ObjectInputStream (
                    new FileInputStream("result.txt"));
            while (true) {
                Player s1 = (Player) in.readObject();
                p.add(s1);
            }
        }
        catch (EOFException e) {
            return p;
        }
        catch (FileNotFoundException e){
            File f1= new File("result.txt");
            f1.createNewFile();
        }

        finally {
            if (in!=null)
                in.close();
        }
        return new ArrayList<Player>();
    }

    public void addToPane(Levels level, AllLevelController myController){
        GridPane pane = myController.lawnPane;
        ArrayList<Plant> plants=level.plants;
        ArrayList<Zombies> zombies =level.zombies;
        ArrayList<Sun> suns=level.suns;
        level.suns=new ArrayList<Sun>();
        level.peas=new ArrayList<Pea>();

        for(int i=0;i<plants.size();i++){
            Plant p = plants.get(i);
            System.out.println(p.getClass().getName());
            p.iv=new ImageView(Main.images.get(p.getClass().getName()));
            p.iv.setVisible(true);
            if(p.getClass().getName()=="sample.Barrier"){
                p.rotwalnut();
            }
            pane.add(p.iv, p.x, p.y);

        }

        for(int i=0;i<zombies.size();i++){
            Zombies z = zombies.get(i);
            z.iv=new ImageView(Main.images.get(z.getClass().getName()));
            //System.out.println(p.iv+ "sdfghhhhhhhhhhhhhhhh"+ "  "+ p.iv+ "  "+ p.x+ "  "+ p.y);
            z.iv.setVisible(true);

            pane.add(z.iv, 6, z.ypos);

        }


        myController.startGame5((Level5)level);


    }
//        catch(NullPointerException e){
//            System.out.println("nulllllllllllll at Main");
//        }
//    }





}