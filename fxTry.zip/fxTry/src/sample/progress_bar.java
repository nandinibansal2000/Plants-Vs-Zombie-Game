package sample;

public class progress_bar {
    private int value;
    progress_bar(){

    }public int getvalue(){
        return value;
    }public void setvalu(int v){
        this.value=v;
    }
}
