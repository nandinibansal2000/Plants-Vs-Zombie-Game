package sample;

import javafx.event.EventHandler;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import jdk.nashorn.internal.ir.annotations.Ignore;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

public class Levels implements Serializable {
    private static final long SerialVersionUID=6L;
    int levelNo;
    //Main main;
    AllLevelController myController;
   static boolean appearsunflower=false;
   static boolean appearcherrybomb=false;
   static boolean appearwalnut=false;
   static boolean appearpeashooter=false;
    ArrayList<Sun> suns;
    ArrayList<Pea> peas;
    ArrayList<Zombies> zombies;
    ArrayList<Sun> sun;
    ArrayList<String> availablePlant;
    ArrayList<String> availableZombies;
    ArrayList<ImageView> lm;
    int suncounter1=0;
//    boolean availablesunflower=false;
    int[] available=new int[4];
    //pea,sun,walnut,cherry


    ArrayList<Plant> plants;
    transient static ArrayList<ImageView> tiles=new ArrayList<ImageView>();
    public Levels(ArrayList<String> p, ArrayList<String> z){
        peas=new ArrayList<Pea>();
        suns=new ArrayList<Sun>();
        zombies=new ArrayList<Zombies>();
        peas=new ArrayList<Pea>();
        plants=new ArrayList<Plant>();
        availableZombies=z;
        availablePlant=p;
        peas=new ArrayList<Pea>();
        lm= new ArrayList<ImageView>();
    }
    public Levels(){
        availableZombies=new ArrayList<String>();
    }
    public void createmow(Levels l,AllLevelController myController){

//       l.lm.add(new LawnMower(myController.getmow1()));
//        l.lm.add(myController.getmow2());
//        l.lm.add(myController.getmow3());
//        l.lm.add(myController.getmow4());
//        l.lm.add(myController.getmow5());
//        return l.lm;
            myController.createmow(l.lm);

    }
    public void update_available(AllLevelController mycontroller, Levels l, Image i1, Image i11, Image i2, Image i22, Image i3, Image i33, Image i4, Image i44){
        for(int i=0;i<4;i++){
            if(l.available[i]!=0 && l.available[i]>0){
                l.available[i]-=1;

            }
            if(l.available[0]==0){
                mycontroller.getpeashooter().imageProperty().setValue(i1);
            }else{
                mycontroller.getpeashooter().imageProperty().setValue(i11);
            }
            if(l.available[1]==0){
                mycontroller.getsunflower().imageProperty().setValue(i2);
            }else{
                mycontroller.getsunflower().imageProperty().setValue(i22);

            }
            if(l.available[2]==0){
                mycontroller.getwalnut().imageProperty().setValue(i3);

            }else{
                mycontroller.getwalnut().imageProperty().setValue(i33);

            }
            if(l.available[3]==0){
                mycontroller.getcherrybomb().imageProperty().setValue(i4);;
            }else{
                mycontroller.getcherrybomb().imageProperty().setValue(i44);;

            }
        }


    }
//    public ArrayList<ImageView> createmow(ArrayList<ImageView> iv){
//        iv.add(mow1);
//        iv.add(mow2);
//        iv.add(mow3);
//        iv.add(mow4);
//        iv.add(mow5);
//    }


    public void checkSunClick(Text sunCounter, ArrayList<Sun> suns, GridPane lawnPane,AllLevelController myController,Levels l) {
        Iterator iterr = suns.iterator();
        int i=-1;
        while (iterr.hasNext()) {
            i++;
            Sun n = (Sun) iterr.next();
            if (n.iv.isVisible()){
            n.iv.addEventHandler(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {

                @Override
                public void handle(MouseEvent event) {
                    if (n.iv.isVisible()){

                            System.out.println("Tileyyyy pressed " + n.iv.isVisible());
                            //Sun.sunCount += 10;

                            l.suncounter1+=50;
                            myController.setSunCounter(l.suncounter1);
//                            sunCounter.setText(Sun.sunCount + "");
                            n.iv.setVisible(false);
                            event.consume();
                    }
                }
            });

        }}
        Iterator iter = suns.iterator();
        while(iter.hasNext()){
            Sun temp=(Sun)iter.next();
            if (!temp.iv.isVisible()){
                iter.remove();
                lawnPane.getChildren().remove(temp.iv);
            }
        }
    }

    public static void tile_list_maker(AllLevelController myController){
        tiles=myController.createlist(tiles);
    }

    public void checkCollision(ArrayList<Zombies>zombies , ArrayList<Pea> peas, GridPane lawnPane,Levels l) {
        Iterator iterator = zombies.iterator();
        while (iterator.hasNext()){
            Zombies z=(Zombies)iterator.next();
            Iterator iter=peas.iterator();
            while(iter.hasNext()){
                {
                    Pea p=(Pea)iter.next();

                    if (p.iv.getBoundsInParent().intersects(z.iv.getBoundsInParent()) && p.hit==false) {
                        System.out.println(p.iv.getBoundsInParent()+ "  --------   "+ z.iv.getBoundsInParent());
                        p.hit=true;
                        // p.iv.setVisible(false);
                        lawnPane.getChildren().remove(p.iv);
                        iter.remove();

                        z.sethits();
                        System.out.println("yayaya" + z.gethits());
                        if (z.gethits() >5) {
                            // z.iv.setVisible(false);
//                                z.iv= new ImageView();
                            z.iv.imageProperty().setValue(new Image(getClass().getResourceAsStream("assets/zombies/burnt.gif")));
                            z.iv.setFitWidth(50);
                            z.iv.setFitHeight(100);

                        }
                        if(z.gethits()>6){
                            iterator.remove();
                            lawnPane.getChildren().remove(z.iv);
                        }
                    }
                }
            }






        }
        Iterator iterz = zombies.iterator();
        while (iterz.hasNext()){
            Zombies z=(Zombies)iterz.next();
            Iterator iterp=plants.iterator();
            while(iterp.hasNext()){
                {
                    Plant p=(Plant)iterp.next();
//                    PeaShooter s=new PeaShooter(0,0,new GridPane());
//                    Sunflower s1=new Sunflower(0,0,new GridPane());
                    if(p.getClass().getName()=="sample.PeaShooter" || p.getClass().getName()=="sample.Sunflower"){
                        if (p.iv.getBoundsInParent().intersects(z.iv.getBoundsInParent())) {
                            p.health-=1;
                            if(p.health<1){
                                lawnPane.getChildren().remove(p.iv);
                                iterp.remove();

                                z.iv.imageProperty().setValue(new Image(getClass().getResourceAsStream("assets/zombies/bucketHead1.gif")));
                                z.iv.setFitWidth(100);
                                z.iv.setFitHeight(100);

                            }else {


                                System.out.println("kkkkkkkk");
                                z.iv.imageProperty().setValue(new Image(getClass().getResourceAsStream("assets/zombies/eating.gif")));
                                z.iv.setFitWidth(100);
                                z.iv.setFitHeight(100);

                            }
                        }
                    }
                }
            }






        }

        Iterator iterz1 = zombies.iterator();
        while (iterz1.hasNext()){
            Zombies z=(Zombies)iterz1.next();
            Iterator iterp1=l.plants.iterator();


            while(iterp1.hasNext()){
                {
                    Plant p=(Plant)iterp1.next();

//                    BombPlant b=new BombPlant(0,0,new GridPane());
//                    Barrier br=new Barrier(0,0,new GridPane());
                    if(p.getClass().getName()=="sample.BombPlant"){
//                        System.out.println("classssssssssssss");
                        if (p.iv.getBoundsInParent().intersects(z.iv.getBoundsInParent()) ) {

                            if(p.health<-400 && p.health>-500){
                                z.iv.imageProperty().setValue(new Image(getClass().getResourceAsStream("assets/zombies/burnt.gif")));
                            }else if(p.health<=-500){
                                iterz1.remove();
                                lawnPane.getChildren().remove(z.iv);
                            }
                        }
                    }else if(p.getClass().getName()=="sample.Barrier"){
                        if (p.iv.getBoundsInParent().intersects(z.iv.getBoundsInParent()) ) {

//                            if(p.health<-400 && p.health>-500){
                                z.iv.imageProperty().setValue(new Image(getClass().getResourceAsStream("assets/zombies/burnt.gif")));
//                            }else if(p.health<=-500){
                                iterz1.remove();
                                lawnPane.getChildren().remove(z.iv);
//                            }
                        }
                    }
                }
            }






        }
//        Iterator iterz2 = zombies.iterator();
//        while (iterz2.hasNext()){
//            Zombies z=(Zombies)iterz2.next();
//            Iterator iterp1=l.plants.iterator();
//
//
//            while(iterp1.hasNext()){
//                {
//                    Plant p=(Plant)iterp1.next();
//
////                    BombPlant b=new BombPlant(0,0,new GridPane());
////                    Barrier br=new Barrier(0,0,new GridPane());
//                    if(p.getClass().getName()=="sample.BombPlant"){
////                        System.out.println("classssssssssssss");
//                        if (p.iv.getBoundsInParent().intersects(z.iv.getBoundsInParent()) ) {
//
//                            if(p.health<-400 && p.health>-500){
//                                z.iv.imageProperty().setValue(new Image(getClass().getResourceAsStream("assets/zombies/burnt.gif")));
//                            }else if(p.health<=-500){
//                                iterz1.remove();
//                                lawnPane.getChildren().remove(z.iv);
//                            }
//                        }
//                    }else if(p.getClass().getName()=="sample.Barrier"){
//                        if (p.iv.getBoundsInParent().intersects(z.iv.getBoundsInParent()) ) {
//
////                            if(p.health<-400 && p.health>-500){
//                            z.iv.imageProperty().setValue(new Image(getClass().getResourceAsStream("assets/zombies/burnt.gif")));
////                            }else if(p.health<=-500){
//                            iterz1.remove();
//                            lawnPane.getChildren().remove(z.iv);
////                            }
//                        }
//                    }
//                }
//            }
//
//
//
//
//
//
//        }
//




    }
    public void blast(Levels l, GridPane lawnpane){
        BombPlant b=new BombPlant(0,0,new GridPane());

//        System.out.println("lllllllllll"+p.size());
        Iterator p=l.plants.iterator();

        while(p.hasNext()) {
//            System.out.println("jjjjjjjjjjjjjjj"+l.plants.get(i).getClass().getName());
            Plant y=(Plant)p.next();
            if(y.getClass()==b.getClass())
            {
//                 System.out.println("kkkkkkkkkkkk");

                int x=y.health;
                if(x==-400){
//                    p.get(i).iv.setImage();
//                    System.out.println("aaaaaaaaaaaaaaaaaaaaaa");
                    y.iv.imageProperty().setValue(new Image(getClass().getResourceAsStream("assets/plants/fire.png")));
                    y.iv.setFitHeight(200);
                    y.iv.setFitWidth(200);

                }
                if(y.health<=-800){

                    lawnpane.getChildren().remove(y.iv);
                    p.remove();


                }
                y.health-=1;
            }
        }
    }

    public void checkSunflowerclick(AllLevelController myController,Levels l) {

        ImageView sunFlower=myController.getsunflower();
        if (l.suncounter1>=50){
        sunFlower.addEventHandler(MouseEvent.MOUSE_CLICKED, event -> {
//                boolean x=
                if(appearsunflower==false && l.available[1]==0 ){
//                   Image sunf = new Image(getClass().getResourceAsStream("assets/plants/sunflower.gif"));
//                   ImageView sunf1=new ImageView(sunf);
//                   lawnPane.add(sunf1,0,3);
                    System.out.println("ufffffffff");
                    appearsunflower=true;
                    checkappearSunflower(myController,l);
                }
                    event.consume();
                }

        );}


    }


    private void checkappearSunflower(AllLevelController myController,Levels l) {
        Iterator iterator = tiles.iterator();

        boolean checker=false;
        try {
            System.out.println(tiles.size());
            while (iterator.hasNext()) {
                if (appearsunflower && l.available[1]==0 && l.suncounter1>=50) {
                    ImageView n = (ImageView) iterator.next();
                    n.addEventHandler(MouseEvent.MOUSE_CLICKED,
                            new EventHandler<MouseEvent>() {

                                @Override
                                public void handle(MouseEvent event) {

                                    if (appearsunflower && l.available[1]==0 && l.suncounter1>=50) {
                                        System.out.println("Tiley pressed ");
                                        Image sunf = new Image(getClass().getResourceAsStream("assets/plants/sunflower.gif"));
                                        ImageView sunf1 = new ImageView(sunf);

                                        String s1 = n.getId();
                                        int y = Integer.parseInt(String.valueOf(s1.charAt(s1.length() - 2))) - 1;
                                        int x = Integer.parseInt(String.valueOf(s1.charAt(s1.length() - 1)));
                                        System.out.println(x + " " + y);
                                        Plant sf= new Sunflower(x,y,myController.lawnPane);
                                       l.available[1]=300;
                                       l.suncounter1-=50;
                                       myController.setSunCounter(l.suncounter1);
                                        myController.lawnPane.add(sf.iv,x,y);
                                        l.plants.add(sf);
                                        //myController.lawnPane.add(sunf1, x, y);
                                        appearsunflower=false;
                                        event.consume();

                                    }}
                            });
                }
                else break;

            }
        }
        finally{

        }

    }
    public void checkwalnutclick(AllLevelController myController,Levels l) {

        ImageView sunFlower=myController.getwalnut();
        if(l.suncounter1>=50){
        sunFlower.addEventHandler(MouseEvent.MOUSE_CLICKED, event -> {
//                boolean x=
                    if(appearwalnut==false && l.available[2]==0 ){
//                   Image sunf = new Image(getClass().getResourceAsStream("assets/plants/sunflower.gif"));
//                   ImageView sunf1=new ImageView(sunf);
//                   lawnPane.add(sunf1,0,3);
                        System.out.println("ufffffffff");
                        appearwalnut=true;
                        checkappearwalnut(myController,l);
                    }
                    event.consume();
                }

        );}


    }


    private void checkappearwalnut(AllLevelController myController,Levels l) {
        Iterator iterator = tiles.iterator();

        boolean checker=false;
        try {
            System.out.println(tiles.size());
            while (iterator.hasNext()) {
                if (appearwalnut && l.available[2]==0 && l.suncounter1>=50) {
                    ImageView n = (ImageView) iterator.next();
                    n.addEventHandler(MouseEvent.MOUSE_CLICKED,
                            new EventHandler<MouseEvent>() {

                                @Override
                                public void handle(MouseEvent event) {

                                    if (appearwalnut && l.available[2]==0 && l.suncounter1>=50 ) {
                                        System.out.println("Tiley pressed ");
//                                        Image sunf = new Image(getClass().getResourceAsStream("assets/plants/sunflower.gif"));
//                                        ImageView sunf1 = new ImageView(sunf);

                                        String s1 = n.getId();
                                        int y = Integer.parseInt(String.valueOf(s1.charAt(s1.length() - 2))) - 1;
                                        int x = Integer.parseInt(String.valueOf(s1.charAt(s1.length() - 1)));
                                        System.out.println(x + " " + y);
                                        Plant sf= new Barrier(x,y,myController.lawnPane);
                                        l.available[2]=300;
                                        l.suncounter1-=50;
                                        myController.setSunCounter(l.suncounter1);
                                        myController.lawnPane.add(sf.iv,x,y);
                                        l.plants.add(sf);
                                        //myController.lawnPane.add(sunf1, x, y);
                                        appearwalnut=false;
                                        event.consume();

                                    }}
                            });
                }
                else break;

            }
        }
        finally{

        }

    }
    public void checkcherrybombclick(AllLevelController myController,Levels l) {

        ImageView sunFlower=myController.getcherrybomb();
        if(l.suncounter1>=150){
        sunFlower.addEventHandler(MouseEvent.MOUSE_CLICKED, event -> {
//                boolean x=
                    if(appearcherrybomb==false && l.available[3]==0 && l.suncounter1>=150){
//                   Image sunf = new Image(getClass().getResourceAsStream("assets/plants/sunflower.gif"));
//                   ImageView sunf1=new ImageView(sunf);
//                   lawnPane.add(sunf1,0,3);
                        System.out.println("ufffffffff");
                        appearcherrybomb=true;
                        checkappearcherrybomb(myController,l);
                    }
                    event.consume();
                }

        );}


    }


    private void checkappearcherrybomb(AllLevelController myController,Levels l) {
        Iterator iterator = tiles.iterator();

        boolean checker=false;
        try {
            System.out.println(tiles.size());
            while (iterator.hasNext()) {
                if (appearcherrybomb && l.available[3]==0 && l.suncounter1>=150) {
                    ImageView n = (ImageView) iterator.next();
                    n.addEventHandler(MouseEvent.MOUSE_CLICKED,
                            new EventHandler<MouseEvent>() {

                                @Override
                                public void handle(MouseEvent event) {

                                    if (appearcherrybomb && l.available[2]==0 && l.suncounter1>=150) {
                                        System.out.println("Tiley pressed ");
                                        Image sunf = new Image(getClass().getResourceAsStream("assets/plants/sunflower.gif"));
                                        ImageView sunf1 = new ImageView(sunf);

                                        String s1 = n.getId();
                                        int y = Integer.parseInt(String.valueOf(s1.charAt(s1.length() - 2))) - 1;
                                        int x = Integer.parseInt(String.valueOf(s1.charAt(s1.length() - 1)));
                                        System.out.println(x + " " + y);
                                        Plant sf= new BombPlant(x,y,myController.lawnPane);
                                        myController.lawnPane.add(sf.iv,x,y);
                                        l.available[3]=300;
                                        l.plants.add(sf);
                                        l.suncounter1-=150;
                                        myController.setSunCounter(l.suncounter1);
                                        //myController.lawnPane.add(sunf1, x, y);
                                        appearcherrybomb=false;
                                        event.consume();

                                    }}
                            });
                }
                else break;

            }
        }
        finally{

        }

    }
    public void checkpeashooterclick(AllLevelController myController,Levels l) {

        ImageView sunFlower=myController.getpeashooter();
        if(l.suncounter1>=100){
        sunFlower.addEventHandler(MouseEvent.MOUSE_CLICKED, event -> {
//                boolean x=
                    if(appearpeashooter==false && l.available[0]==0){
//                   Image sunf = new Image(getClass().getResourceAsStream("assets/plants/sunflower.gif"));
//                   ImageView sunf1=new ImageView(sunf);
//                   lawnPane.add(sunf1,0,3);
                        System.out.println("ufffffffff");
                        appearpeashooter=true;
                        checkappearpeashooter(myController,l);
                    }
                    event.consume();
                }

        );}


    }


    private void checkappearpeashooter(AllLevelController myController,Levels l) {
        Iterator iterator = tiles.iterator();

        boolean checker=false;
        try {
            System.out.println(tiles.size());
            while (iterator.hasNext()) {
                if (appearpeashooter && l.available[0]==0 && l.suncounter1>=100) {
                    ImageView n = (ImageView) iterator.next();
                    n.addEventHandler(MouseEvent.MOUSE_CLICKED,
                            new EventHandler<MouseEvent>() {

                                @Override
                                public void handle(MouseEvent event) {

                                    if (appearpeashooter && l.available[0]==0 && l.suncounter1>=100) {
                                        System.out.println("Tiley pressed ");
                                        System.out.println("lllllllllllllll");

                                        Image sunf = new Image(getClass().getResourceAsStream("assets/plants/peashooter.gif"));
                                        ImageView sunf1 = new ImageView(sunf);

                                        String s1 = n.getId();
                                        int y = Integer.parseInt(String.valueOf(s1.charAt(s1.length() - 2))) - 1;
                                        int x = Integer.parseInt(String.valueOf(s1.charAt(s1.length() - 1)));
                                        System.out.println(x + " " + y);
                                        Plant sf= new PeaShooter(x,y,myController.lawnPane);
                                        l.available[0]=300;
                                        myController.lawnPane.add(sf.iv,x,y);
                                        l.plants.add(sf);
                                        l.suncounter1-=100;
                                        myController.setSunCounter(l.suncounter1);
                                        //myController.lawnPane.add(sunf1, x, y);
                                        appearpeashooter=false;
                                        event.consume();

                                    }}
                            });
                }
                else break;

            }
        }
        finally{

        }

    }
}
class Level1 extends Levels{
    AllLevelController myController;

    Level1(Level1Controller c){

        super(new ArrayList<String>(
                Arrays.asList("Sunflower", "PeaShooter")),new ArrayList<String>(
                Arrays.asList("Normal")));
        levelNo=1;
        this.myController=c;

    }

}

class Level2 extends Levels{
    AllLevelController c;
    Level2(Level2Controller c){
        super(new ArrayList<String>(
                Arrays.asList("Sunflower", "PeaShooter", "Potato")),new ArrayList<String>(
                Arrays.asList("Normal")));
        levelNo=2;
        this.myController=c;
    }
}
class Level3 extends Levels{
    AllLevelController myController;
    Level3(Level3Controller c){
        super(new ArrayList<String>(
                Arrays.asList("Sunflower", "PeaShooter")),new ArrayList<String>(
                Arrays.asList("Normal", "Buckethead")));
        levelNo=3;
        this.myController=c;
    }
}
class Level4 extends Levels{
    AllLevelController myController;
    Level4(Level4Controller c){
        super(new ArrayList<String>(
                Arrays.asList("Sunflower", "PeaShooter", "Cherrybomb")),new ArrayList<String>(
                Arrays.asList("Normal", "Buckethead")));
        levelNo=4;
        this.myController=c;
    }
}
class Level5 extends Levels {

    AllLevelController myController;
    Level5(Level5Controller lc) {
        super(new ArrayList<String>(
                Arrays.asList("Sunflower", "PeaShooter", "Cherrybomb")), new ArrayList<String>(
                Arrays.asList("Conehat", "Buckethead")));
        this.myController = lc;
        levelNo=5;
    }
}



