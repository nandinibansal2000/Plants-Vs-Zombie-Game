package sample;

import javafx.animation.TranslateTransition;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.util.Duration;

import javax.swing.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;

public class Sun implements Serializable {
    private static final long SerialVersionUID=11L;
    transient Image sun_img;
    transient ImageView iv;
    static int count=0;
    private int sunTime;
    public static  int sunCount=0;
    //= new Image("file:assets/Giant_Pea2.png");
    public Sun(int x, GridPane pane){
        sun_img= new Image(getClass().getResourceAsStream("assets/sun.png"));
        iv = new ImageView();
        iv.setFitWidth(90);
        iv.setFitHeight(90);
        iv.setImage(sun_img);
        iv.setId("sun"+count++);

        this.placeSun(x,0, pane);
    }

    public Sun(int x,int y, GridPane pane){
        sun_img= new Image(getClass().getResourceAsStream("assets/sun.png"));
        iv = new ImageView();
        iv.setFitWidth(90);
        iv.setFitHeight(90);
        iv.setImage(sun_img);
        iv.setId("sun"+count++);

        this.placeSun(x,y, pane);
    }

    public int getSunTime() {
        return sunTime;
    }

    public static void generateSun(GridPane lawnPane, Levels l) {
        Sun sun=null;
        if (RandomGenerator.getInstance().getRandom(500) == 1){
            sun=new Sun(RandomGenerator.getInstance().getRandom(7),lawnPane);
            l.suns.add(sun);
            sun.moveSun((int)(Math.random()*(400)));
        }

    }

    public static void removeExpiredSun(GridPane lawnPane, Levels l) {
        Iterator iterator = l.suns.iterator();


        while (iterator.hasNext()){
            Sun n = (Sun)iterator.next();
            if (n.getSunTime()==1000){
                //n.iv.setVisible(false);
                iterator.remove();
                lawnPane.getChildren().remove(n.iv);

            }
        }
    }

    public static void updateSunTimer(Levels l) {
        ArrayList<Sun> suns = l.suns;
        Iterator iterator = suns.iterator();
        while (iterator.hasNext()){
            Sun n = (Sun)iterator.next();
            n.sunTime++;
        }
    }

    public void placeSun(int x, int y, GridPane pane){
        pane.add(iv, x, y);

    }

    public void moveSun(int y){
        TranslateTransition translate = new TranslateTransition();
        translate.setDuration(Duration.seconds((int)(y/40)));
        //Setting the X,Y,Z coordinates to apply the translation
        translate.setToX(4);
        translate.setToY(y);
        translate.setNode(this.iv);
        translate.play();
    }
}
