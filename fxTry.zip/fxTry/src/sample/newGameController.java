package sample;

import com.sun.xml.internal.ws.policy.privateutil.PolicyUtils;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.scene.transform.Translate;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;

public class newGameController {

//    @Override
//    public void initialize(URL url, ResourceBundle resourceBundle) {
//
//    }
    @FXML
    private transient Button createUser;
    @FXML
    private transient TextArea getNameBox;

    public Button getCreateUserBtn(){
        return createUser;
    }

    @FXML
    public void gotoMMScene(MouseEvent event) throws IOException {
        Parent parent1 = FXMLLoader.load(getClass().getResource("mainMenu.fxml"));
        Scene scene1 = new Scene(parent1);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene1);
        window.show();
    }

    @FXML
    public void gotoLevel(MouseEvent event) throws IOException {
        Parent parent1 = FXMLLoader.load(getClass().getResource("level5.fxml"));
        Scene scene1 = new Scene(parent1);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene1);
        window.show();
    }

    @FXML
    public void checkButtonClick() throws IOException {
        /////change leve5 to level1
        createUser.addEventHandler(MouseEvent.MOUSE_CLICKED, event -> {
                    String name= getNameBox.getText();
                    try {
                        Player player = new Player(name);

                        Main.addPlayer(player);

                        FXMLLoader loader = new FXMLLoader(getClass().getResource("level5.fxml"));
                        Level5Controller myController;
                        Level5 level5;
                        Parent parent1 = loader.load();

                        myController = (Level5Controller) loader.getController();

                        level5 = new Level5(myController);
                        player.levels.add(level5);
                        myController.startGame5(level5);
                        Levels.tile_list_maker(myController);

                        Scene scene1 = new Scene(parent1);
                        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
                        window.setScene(scene1);
                        window.show();
                        System.out.print("sffffffffffffffff-------");
                    }
                     catch (IOException e) {
                        e.printStackTrace();
                    }


//            }
                    event.consume();
                }

        );
    }

}