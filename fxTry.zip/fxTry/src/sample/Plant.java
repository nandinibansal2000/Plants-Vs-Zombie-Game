package sample;

import javafx.animation.RotateTransition;
import javafx.animation.TranslateTransition;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.transform.Rotate;
import javafx.util.Duration;
import org.omg.PortableInterceptor.SYSTEM_EXCEPTION;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.logging.Level;

public abstract class Plant implements Serializable {
    private static final long SerialVersionUID=1L;
    String type;
    transient ImageView iv;
    static int count=0;
    private final String id;
    int health=50;
    int x;
    int y;


    public Plant(int x, int y, GridPane pane){
        //iv.setId("pea"+count++);
        id="Plant"+count++;
        this.x=x;
        this.y=y;

        //this.placePea(x, y, pane);
    }
    public Plant(){
        id=0+"";
    }
    public void rotwalnut(){

    }
}


class Barrier extends Plant{
    transient Image plant_img =new Image(getClass().getResourceAsStream("assets/plants/walnut.gif"));;

    Barrier(int x, int y, GridPane pane){
        super(x,y, pane);
        iv=new ImageView();
        iv.setFitWidth(150);
        iv.setFitHeight(110);
        iv.setImage(plant_img);
        type="Barrier";
        rotwalnut();

    }

    public void rotwalnut() {
        RotateTransition rotate=new RotateTransition();
        rotate.setDuration(Duration.seconds(80));
        //Setting the X,Y,Z coordinates to apply the translation
//        rotate.setToX(-800);
//        .setToY(y);
//        translate.setNode(this.iv);
//        translate.play();
        rotate.setAxis(Rotate.Z_AXIS);

        // setting the angle of rotation
        rotate.setByAngle(360);

        //setting cycle count of the rotation
        rotate.setCycleCount(500);

        //Setting duration of the transition
        rotate.setDuration(Duration.millis(800));

        //the transition will be auto reversed by setting this to true
//        rotate.setAutoReverse(true);

        //setting Rectangle as the node onto which the
// transition will be applied
        rotate.setNode(this.iv);

        //playing the transition
        rotate.play();
        TranslateTransition translate = new TranslateTransition();
        translate.setDuration(Duration.seconds(10));
        //Setting the X,Y,Z coordinates to apply the translation
        translate.setToX(800);
        translate.setToY(y);
        translate.setNode(this.iv);
        translate.play();
        //System.out.println("ssssssssssssssssssssssssssssss");

    }
}



class BombPlant extends Plant{
    transient Image plant_img =new Image(getClass().getResourceAsStream("assets/plants/cherrybomb.gif"));;

    BombPlant(int x, int y, GridPane pane){
        super(x,y, pane);
        iv=new ImageView();
        iv.setFitWidth(150);
        iv.setFitHeight(180);
        iv.setImage(plant_img);



    }
}

class PeaShooter extends Plant{
    transient Image plant_img= new Image(getClass().getResourceAsStream("assets/plants/peashooter.gif"));
    //ImageView iv;
    PeaShooter(int x, int y, GridPane pane){
        super(x,y,pane);
        super.iv = new ImageView();
        super.iv.setFitWidth(70);
        super.iv.setFitHeight(70);
        super.iv.setImage(plant_img);
    }

    transient ImageView shooterPlant;

}

class Sunflower extends Plant{
    transient Image plant_img =new Image(getClass().getResourceAsStream("assets/plants/sunflower.gif"));;

    Sunflower(int x, int y, GridPane pane){
        super(x,y, pane);
        iv=new ImageView();
        iv.setFitWidth(80);
        iv.setFitHeight(80);
        iv.setImage(plant_img);

    }

    public static void generateSun(int clock, GridPane lawnPane, Levels l) {
        if (clock%500 == 0) {
            //l.pla
            ArrayList<Plant> p1=l.plants;
            for(int i=0;i<p1.size();i++){
                if(p1.get(i).getClass()==new Sunflower(0,0,new GridPane()).getClass()){
                    Sun sun = null;
                    int x=p1.get(i).x;
                    int y=p1.get(i).y;
                    sun = new Sun(x, y, lawnPane);
                    l.suns.add(sun);}

            }
        }
    }

}

class Pea implements Serializable{
    private static final long SerialVersionUID=2L;
    transient  Image pea_img;
    boolean hit=false;
    transient ImageView iv;
    static int count=0;
    //= new Image("file:assets/Giant_Pea2.png");
    public Pea(int x, int y, GridPane pane){
        pea_img= new Image(getClass().getResourceAsStream("assets/Giant_Pea2.png"));
        iv = new ImageView();
        iv.setFitWidth(30);
        iv.setFitHeight(30);
        iv.setImage(pea_img);
        iv.setId("pea"+count++);

        this.placePea(x, y,pane);
    }

    public void placePea(int x, int y, GridPane pane){
        iv.setScaleZ(-10);
        pane.add(iv, x, y);

    }

    public void movePea(){
        TranslateTransition translate = new TranslateTransition();
        translate.setDuration(Duration.seconds(20));
        //Setting the X,Y,Z coordinates to apply the translation
        translate.setToX(800);
        translate.setToY(-2);
        translate.setNode(this.iv);
        //System.out.println(translate.x);

        translate.play();
    }

    public static void generatePea(int clock, GridPane lawnPane, Levels l) {
        if (clock%500 == 0) {
            //l.pla
            ArrayList<Plant> p1=l.plants;
            for(int i=0;i<p1.size();i++){
                if(p1.get(i).getClass()==new PeaShooter(0,0,new GridPane()).getClass()){
                    Pea pea1 = null;
                    int x=p1.get(i).x;
                    int y=p1.get(i).y;
                    pea1 = new Pea(x, y, lawnPane);
                    pea1.movePea();
                    l.peas.add(pea1);}

            }
        }
    }


}
