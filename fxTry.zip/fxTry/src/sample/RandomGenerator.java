package sample;

public class RandomGenerator {
    static RandomGenerator rg;
    static int rand;
    private RandomGenerator(){

    }
    public static RandomGenerator getInstance() {
        if (rg == null) {
            rg = new RandomGenerator();
        }
        return rg;
    }

    public int getRandom(int n){
        return (int)(Math.random()*n+1);
    }


}
