package sample;

import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;

public abstract class Controllers {
   // public abstract class Controller {

        public abstract GridPane getLawnPane();

        public abstract Text getSunCounter();

        public static ImageView getsunflower(){
            return new ImageView();
        }
    }

