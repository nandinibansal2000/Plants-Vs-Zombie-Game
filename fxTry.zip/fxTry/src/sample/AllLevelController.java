package sample;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;

import java.awt.font.ImageGraphicAttribute;
import java.io.Serializable;
import java.util.ArrayList;

public class AllLevelController implements Serializable {
    private static final long SerialVersionUID=3L;
    public transient GridPane lawnPane;

    public ImageView getsunflower(){
        return new ImageView();
    }

    public ArrayList<ImageView> createlist(ArrayList<ImageView> tiles) {
        return new ArrayList<ImageView>();
    }

    public ImageView getcherrybomb() {
        return new ImageView();
    }
    public ImageView getpeashooter(){
        return new ImageView();
    }
    public ImageView getwalnut(){
        return  new ImageView();
    }

    public int getsuncounter() {
        return 0;
    }

    public void startGame5(Level5 level) {
    }

    public void setSunCounter(int suncounter1) {
    }

//    public LawnMower getmow1() {
//        return new LawnMower();
//    }
//
//    public LawnMower getmow2() {
//        return new LawnMower();
//    } public LawnMower getmow3() {
//        return new LawnMower();
//    }
//
//    public LawnMower getmow4() {
//        return new LawnMower();
//    } public LawnMower getmow5() {
//        return new LawnMower();
//    }


    public void createmow(ArrayList<ImageView> lm) {
    }
}
