package sample;

import java.io.*;
import java.lang.reflect.Array;
import java.util.ArrayList;

public class Player implements Serializable{
    private static final long SerialVersionUID=10l;
    String name="";

    ArrayList<Levels> levels;
    Player(String s){
        levels= new ArrayList<Levels>();

        name=s;
    }
    public String getName(){
        return name;
    }


}
