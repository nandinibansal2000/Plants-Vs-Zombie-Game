package sample;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;


public class LevelController {
    static Level5 level5;


    @FXML
    public void gotoMMScene(MouseEvent event) throws IOException {
        Parent parent1 = FXMLLoader.load(getClass().getResource("mainMenu.fxml"));
        Scene scene1 = new Scene(parent1);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene1);
        window.show();
    }

    @FXML
    public void gotoLevel1(MouseEvent event) throws IOException {
        Parent parent1 = FXMLLoader.load(getClass().getResource("level1.fxml"));
        Scene scene1 = new Scene(parent1);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene1);
        window.show();

    }
    public void gotoLevel2(MouseEvent event) throws IOException {
        Parent parent1 = FXMLLoader.load(getClass().getResource("level2.fxml"));
        Scene scene1 = new Scene(parent1);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene1);
        window.show();
    }

    public void gotoLevel3(MouseEvent event) throws IOException {
        Parent parent1 = FXMLLoader.load(getClass().getResource("level3.fxml"));
        Scene scene1 = new Scene(parent1);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene1);
        window.show();
    }

    public void gotoLevel4(MouseEvent event) throws IOException {
        Parent parent1 = FXMLLoader.load(getClass().getResource("level4.fxml"));
        Scene scene1 = new Scene(parent1);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene1);
        window.show();
    }


    public void gotoLevel5(MouseEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("level5.fxml"));
        Level5Controller myController;

        Parent parent1 = loader.load();

        myController = (Level5Controller) loader.getController();

        level5 = new Level5(myController);
        System.out.println(myController + "----------------------------------------------------");
        myController.startGame5(level5);
        Levels.tile_list_maker(myController);

        Scene scene1 = new Scene(parent1);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene1);
        window.show();
    }
}