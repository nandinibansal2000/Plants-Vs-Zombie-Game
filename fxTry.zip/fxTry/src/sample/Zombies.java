package sample;
import javafx.animation.TranslateTransition;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.util.Duration;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.Serializable;


public class Zombies implements Serializable
{private static final long SerialVersionUID=4L;
    protected static double speed;
    transient protected Image zombie_img;
    transient protected ImageView iv = new ImageView();
    protected static int zombieCount;
    protected int xpos = 7;
    protected int ypos;
    protected int zombie_ID;
    protected int hits = 0;
    static protected int generationFreq=900;

    public void sethits() {
        this.hits += 1;
    }

    public int gethits() {
        return hits;
    }

    protected void placeZombie(int x, int y, GridPane pane) {
        pane.add(this.iv, x, y);
    }


    public void moveZombie(int y) {
        TranslateTransition translate = new TranslateTransition();
        translate.setDuration(Duration.seconds(80));
        //Setting the X,Y,Z coordinates to apply the translation
        translate.setToX(-800);
        translate.setToY(y);
        translate.setNode(this.iv);
        translate.play();
        //System.out.println("ssssssssssssssssssssssssssssss");
    }

    public static void generateZombie(GridPane lawnPane, Levels l) {
        Zombies zomb = null;
        ZombieFactory zombFac = new ZombieFactory();
        RandomGenerator rg = RandomGenerator.getInstance();
        int ypos = rg.getRandom(5)-1;
        if (rg.getRandom(zomb.generationFreq) == 1) {
            zomb = zombFac.createZombies(l.availableZombies, lawnPane, ypos);
            l.zombies.add(zomb);
            zomb.moveZombie(0);
        }

    }
}








class NormalZombie extends Zombies{

}

class ConeHatZombie extends Zombies{
    public ConeHatZombie(GridPane pane, int ypos){
        zombie_img = new Image(getClass().getResourceAsStream("assets/zombies/ConeHead.gif"));
        iv = new ImageView();
        iv.setImage(zombie_img);
        iv.setFitHeight(100);
        iv.setFitWidth(100);
        iv.setId("zombie"+zombieCount++);
        super.placeZombie(xpos, ypos, pane);
    }
}

class TroopLeadZombie extends Zombies{

}

class BucketHeadZombie extends Zombies{
    public BucketHeadZombie(GridPane pane, int ypos) throws FileNotFoundException {

        zombie_img = new Image(getClass().getResourceAsStream("assets/zombies/bucketHead1.gif"));
        iv = new ImageView();
        iv.setImage(zombie_img);
        iv.setFitHeight(120);
        iv.setFitWidth(120);
        iv.setId("zombie"+zombieCount++);
        super.placeZombie(xpos, ypos, pane);

    }
}