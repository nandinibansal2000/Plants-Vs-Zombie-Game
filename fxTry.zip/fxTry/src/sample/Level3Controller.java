package sample;

import javafx.animation.*;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.scene.layout.Pane;
import javafx.util.Duration;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class Level3Controller extends AllLevelController implements Initializable{

    AllLevelController myController;
public static int clock=-1;
Levels level3 = new Level3(this);

    @FXML
    private transient Text sunCounter;
public void setSunCounter(int c){
    sunCounter.setText(Integer.toString(c));
}

    @FXML
    private transient ImageView peashooter;

    @FXML
    private transient Pane ingameMenu;
@FXML
private transient ImageView pea;
@FXML
private transient ImageView z1;
@FXML
private transient ImageView z2;
@FXML
public transient GridPane lawnPane;

@FXML
private transient  ProgressBar ProgressBar;
@FXML
private transient ImageView s_sunfower;
@FXML
private transient ImageView s_peashooter;
@FXML
private transient ImageView s_walnut;
@FXML
private transient ImageView s_cherrybomb;


    @FXML private transient ImageView lightPatch11; @FXML
    private transient ImageView lightPatch12; @FXML
    private transient ImageView lightPatch13; @FXML
    private transient ImageView lightPatch14;  @FXML
    private transient ImageView lightPatch15;  @FXML
    private transient ImageView lightPatch16;  @FXML
    private transient ImageView lightPatch17;  @FXML
    private transient ImageView lightPatch21;  @FXML
    private transient ImageView lightPatch22;  @FXML
    private transient ImageView lightPatch23;  @FXML
    private transient ImageView lightPatch24;  @FXML
    private transient ImageView lightPatch25;  @FXML
    private transient ImageView lightPatch26;  @FXML
    private transient ImageView lightPatch27;  @FXML
    private transient ImageView lightPatch31;  @FXML
    private transient ImageView lightPatch32;  @FXML
    private transient ImageView lightPatch33;  @FXML
    private transient ImageView lightPatch34;  @FXML
    private transient ImageView lightPatch35;  @FXML
    private transient ImageView lightPatch36;  @FXML
    private transient ImageView lightPatch37;  @FXML
    private transient ImageView lightPatch41;  @FXML
    private transient ImageView lightPatch42;
    @FXML
    private transient ImageView lightPatch43; @FXML
    private transient ImageView lightPatch44; @FXML
    private transient ImageView lightPatch45; @FXML
    private transient ImageView lightPatch46;  @FXML
    private transient ImageView lightPatch47;  @FXML
    private transient ImageView lightPatch51;  @FXML
    private transient ImageView lightPatch52;  @FXML
    private transient ImageView lightPatch53;  @FXML
    private transient ImageView lightPatch54;  @FXML
    private transient ImageView lightPatch55;  @FXML
    private transient ImageView lightPatch56;  @FXML
    private transient ImageView lightPatch57;


private double a=0;

    transient FXMLLoader loader = new FXMLLoader(getClass().getResource("level5.fxml"));

    public ArrayList<ImageView> createlist(ArrayList<ImageView> iv){
        iv.add(lightPatch11);
        iv.add(lightPatch12);
        iv.add(lightPatch13);
        iv.add(lightPatch14);
        iv.add(lightPatch15);
        iv.add(lightPatch16);
        iv.add(lightPatch17);
        iv.add(lightPatch21);
        iv.add(lightPatch22);
        iv.add(lightPatch23);
        iv.add(lightPatch24);
        iv.add(lightPatch25);
        iv.add(lightPatch26);
        iv.add(lightPatch27);
        iv.add(lightPatch31);
        iv.add(lightPatch32);
        iv.add(lightPatch33);
        iv.add(lightPatch34);
        iv.add(lightPatch35);
        iv.add(lightPatch36);
        iv.add(lightPatch37);
        iv.add(lightPatch41);
        iv.add(lightPatch42);
        iv.add(lightPatch43);
        iv.add(lightPatch44);
        iv.add(lightPatch45);
        iv.add(lightPatch46);
        iv.add(lightPatch47);
        iv.add(lightPatch51);
        iv.add(lightPatch52);
        iv.add(lightPatch53);
        iv.add(lightPatch54);
        iv.add(lightPatch55);
        iv.add(lightPatch56);
        iv.add(lightPatch57);
        return iv;

    }


    public ImageView getsunflower(){
        return s_sunfower;
    }

    public ImageView getcherrybomb(){
        return s_cherrybomb;
    }

    public ImageView getwalnut(){
        return s_walnut;
    }

    public ImageView getpeashooter(){
        return s_peashooter;
    }

public int getsuncounter(){
        return Integer.parseInt(sunCounter.getText());

}
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        createProgresBar();
        //Level5 level5=LevelController.level5;
        //startGame5(level5);
    }

    //@Override
    public GridPane getLawnPane(){
      return lawnPane;

    }

    public void startGame5(Level3 l5){
        Image i1=(new Image(getClass().getResourceAsStream("assets/buyPlants/buy_peashooter.jpeg")));

        Image i11= (new Image(getClass().getResourceAsStream("assets/buyPlants/un_peashooter.jpeg")));


        Image i2=   (new Image(getClass().getResourceAsStream("assets/buyPlants/buy_sunflower.jpeg")));
        Image i22=  (new Image(getClass().getResourceAsStream("assets/buyPlants/un_sunflower.jpeg")));


        Image i3=  (new Image(getClass().getResourceAsStream("assets/buyPlants/buy_potato.jpeg")));


        Image i33=(new Image(getClass().getResourceAsStream("assets/buyPlants/un_potato.jpeg")));


        Image i4=  (new Image(getClass().getResourceAsStream("assets/buyPlants/buy_cherrybomb.jpeg")));;
        Image i44=   (new Image(getClass().getResourceAsStream("assets/buyPlants/un_cherrybomb.jpeg")));;
        myController = this;
        if (myController==null) myController=l5.myController;
        if (myController==null) myController=new Level5Controller();

        AnimationTimer gameLoop = new AnimationTimer() {

            @Override
            public void handle(long now) {
                clock++;
                Pea.generatePea(clock, lawnPane, l5);
                Sunflower.generateSun(clock, lawnPane, l5);
                Sun.generateSun(lawnPane, l5);
                Zombies.generateZombie(lawnPane,l5);
                Sun.updateSunTimer(l5);
                level3.blast(l5,lawnPane);
                level3.update_available(myController,l5,i1,i11,i2,i22,i3,i33,i4,i44);
                level3.checkCollision(l5.zombies, l5.peas, lawnPane,l5);
                Sun.removeExpiredSun(lawnPane, l5);
                level3.checkSunflowerclick(myController,l5);
                level3.checkcherrybombclick(myController,l5);
                level3.checkpeashooterclick(myController,l5);
                level3.checkwalnutclick(myController,l5);
                level3.checkSunClick(sunCounter, l5.suns, lawnPane,myController,l5);
            }
        };
        gameLoop.start();
    }


    @FXML
    public void gotoMMScene(MouseEvent event) throws IOException {
        Parent parent1 = FXMLLoader.load(getClass().getResource("mainMenu.fxml"));
        Scene scene1 = new Scene(parent1);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene1);
        window.show();
    }
    @FXML
    public void restartLevel(MouseEvent event) throws IOException {
        ingameMenu.setVisible(false);
        //Parent parent1 = FXMLLoader.load(getClass().getResource("level5.fxml"));
        Parent root = loader.load();
        Scene scene1 = new Scene(root);

        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene1);
        window.show();
    }

    @FXML
    public void saveGame(MouseEvent event) throws IOException{
        Main.serialize();;
        System.exit(0);
    }


    @FXML
    public void exitGame(MouseEvent event) throws IOException {

                System.exit(0);
    }

    @FXML
    public void gotoIGMenu(MouseEvent event) throws IOException {
        Parent parent1 = FXMLLoader.load(getClass().getResource("newGame.fxml"));
        Scene scene1 = new Scene(parent1);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene1);
        window.show();
    }



    public void clickme(MouseEvent mouseEvent) {
        ingameMenu.setVisible(true);
    }
@FXML
    public void backtogame(MouseEvent mouseEvent) {
    ingameMenu.setVisible(false);
    }

   //@Override
    public Text getSunCounter() {
        return sunCounter;
    }

    public void createProgresBar(){
        ProgressBar progress = ProgressBar;

        IntegerProperty seconds = new SimpleIntegerProperty();
        progress.progressProperty().bind(seconds.divide(60.0));
        Timeline timeline = new Timeline(
                new KeyFrame(Duration.ZERO, new KeyValue(seconds, 0)),
                new KeyFrame(Duration.minutes(3), e-> {
                    // do anything you need here on completion...
                    System.out.println("Minute over");
                }, new KeyValue(seconds, 60))
        );
        timeline.setCycleCount(Animation.INDEFINITE);
        timeline.play();
    }
}