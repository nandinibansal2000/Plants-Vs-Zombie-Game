package sample;

import javafx.scene.layout.GridPane;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

public class ZombieFactory {
    public Zombies createZombies(ArrayList<String> types, GridPane pane, int ypos) {
        RandomGenerator rg = RandomGenerator.getInstance();
        int ty = rg.getRandom(types.size())-1;
        String type = types.get(ty);
        try {
            if (type.equals("Buckethead")) {

                return new BucketHeadZombie(pane, ypos);
            }
            else if (type.equals("Conehat")) {
                return new ConeHatZombie(pane, ypos);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            return new BucketHeadZombie(pane, ypos);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }
}
