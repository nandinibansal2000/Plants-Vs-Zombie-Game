package sample;

import com.sun.xml.internal.ws.policy.privateutil.PolicyUtils;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import java.io.IOException;
import java.lang.reflect.Array;
import java.net.URL;
import java.util.*;

public class MainMenuController {
    static ArrayList<Button> buttons=new ArrayList<Button>();
//    @Override
//    public void initialize(URL url, ResourceBundle resourceBundle) {
//
//    }

    @FXML
    public void gotoLevelScene(MouseEvent event) throws IOException {
//        System.out.println("dfghfjgkh");
        Parent parent1 = FXMLLoader.load(getClass().getResource("Level.fxml"));
        Scene scene1 = new Scene(parent1);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene1);
        window.show();
    }

    @FXML
    public void gotoSavedGames(MouseEvent event) throws IOException, ClassNotFoundException {
        savedGamesController myController;
        FXMLLoader loader = new FXMLLoader(getClass().getResource("savedGames.fxml"));
        Parent root = loader.load();

        myController = (savedGamesController) loader.getController();
        ScrollPane spane = myController.getSavedGamesBox();
        spane.setPannable(true);
        System.out.println(spane);
        addPlayersName(spane);
        Scene scene1 = new Scene(root);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene1);
        window.show();
    }

    @FXML
    public void createNewGame(MouseEvent event) throws IOException {
        Parent parent1 = FXMLLoader.load(getClass().getResource("newGame.fxml"));
        Scene scene1 = new Scene(parent1);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene1);
        window.show();
    }

    @FXML
    public void exitGame(MouseEvent event){
        System.exit(0);
    }

    public void addPlayersName(ScrollPane spane) throws ClassNotFoundException, IOException{
        VBox contents = new VBox();
        ArrayList<Player> players;
        ArrayList<Button> buttons = new ArrayList<Button>();
        players=Main.deserialize();
        for (int i=0; i<players.size();i++){
            Button t1=new Button(players.get(i).getName());
            buttons.add(t1);
            t1.setId(players.get(i).getName());
            t1.setPrefWidth(400);
            t1.setPrefHeight(50);
            contents.getChildren().add(t1);
        }

        spane.setContent(contents);

        checkButtonClicked(buttons);

    }

    public void checkButtonClicked(ArrayList<Button> buttons){
        for(int i=0;i<buttons.size();i++){
            Button butt= buttons.get(i);
            buttons.get(i).addEventHandler(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>() {

                @Override
                public void handle(MouseEvent event) {
                    try{
                        ArrayList<Player> players = Main.deserialize();
                        Levels level=new Levels();
                        for (int j=0;j<players.size();j++){
                            String a1=players.get(j).name.trim(); String a2=(String)butt.getId().trim();
                            if (a1.equals(a2)){
                                int len =  players.get(j).levels.size();
                                level= players.get(j).levels.get(len-1);
                                startLevel(level, "level"+level.levelNo+".fxml", event);

                            }


                        }}
                    catch (IOException e){

                    }
                    catch (ClassNotFoundException e){

                    }
                }

            });
        }


    }

    public void startLevel(Levels level, String name, MouseEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(name));
        Parent parent1 = loader.load();
        AllLevelController myController=loader.getController();

        Scene scene1 = new Scene(parent1);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene1);
        window.show();

        new Main().addToPane(level, myController);
    }


}