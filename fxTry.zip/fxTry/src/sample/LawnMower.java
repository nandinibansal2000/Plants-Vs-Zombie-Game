package sample;

import javafx.animation.TranslateTransition;
import javafx.scene.image.ImageView;
import javafx.util.Duration;

public class LawnMower {
ImageView i;
LawnMower(ImageView iv){
    i=iv;
}


public void move(ImageView iv){
    TranslateTransition translate = new TranslateTransition();
    translate.setDuration(Duration.seconds(80));
    //Setting the X,Y,Z coordinates to apply the translation
    translate.setToX(+800);
//    translate.setToY(y);
    translate.setNode(iv);
    translate.play();

}

}
