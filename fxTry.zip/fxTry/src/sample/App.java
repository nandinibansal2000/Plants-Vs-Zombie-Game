package sample;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

public class App extends Application {
    static transient MainMenuController myController;
    @Override
    public void start(Stage primaryStage) throws Exception{
        Main.images.put("sample.BombPlant", new Image(getClass().getResourceAsStream("assets/plants/cherrybomb.gif")));
        Main.images.put("sample.PeaShooter", new Image(getClass().getResourceAsStream("assets/plants/peashooter.gif")));
        Main.images.put("sample.Sunflower", new Image(getClass().getResourceAsStream("assets/plants/sunflower.gif")));
        Main.images.put("sample.Pea", new Image(getClass().getResourceAsStream("assets/Giant_Pea2.png")));
        Main.images.put("sample.Barrier", new Image(getClass().getResourceAsStream("assets/plants/walnut.gif")));
        Main.images.put("sample.BucketHeadZombie", new Image(getClass().getResourceAsStream("assets/zombies/bucketHead1.gif")));
        Main.images.put("sample.ConeHatZombie", new Image(getClass().getResourceAsStream("assets/zombies/ConeHead.gif")));



        FXMLLoader loader = new FXMLLoader(getClass().getResource("mainMenu.fxml"));
        Parent root = loader.load();

        myController = (MainMenuController) loader.getController();
        //lawnPane=myController.getLawnPane();
        //Levels level5 = new Level5(myController);


        primaryStage.setTitle("pVz");
        primaryStage.setScene(new Scene(root, 1080, 600));
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}